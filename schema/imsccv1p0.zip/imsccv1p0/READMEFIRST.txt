IMSCCv1p0.zip - IMS Common Cartridge v1.0 specification


This is the readmefirst.txt file for the package containing the IMS Common Cartridge v1.0 specification

The package conttains the following files:


	File Name			Description			Package Location

	READMEFIRST.txt			This file			/READMEFIRST.txt   

	ccv1p0speclicense.html		CC specification license	/ccv1p0speclicense.html  

	imscc_profilev1p0.pdf		The Common Cartridge 		/ccv1p0/imscc_profilev1p0.pdf
					specification

	imscc_profilev1p0.html		The Common Cartridge 		/ccv1p0/imscc_profilev1p0.html
					specification

	ccV1p0.zip (*)			The Common Cartridge profiled	/ccv1p0/ccV1p0.zip 
					schema set

	imscc_authv1p0.pdf		The Common Cartridge		/authv1p0/imscc_authV1p0.pdf
					Authorization specification

	imscc_authv1p0.html		The Common Cartridge		/authv1p0/imscc_authV1p0.html
					Authorization specification

	imsccauth_v1p0.xsd		The Common Cartridge 		/authv1p0/imsccauth_v1p0.xsd 
					Authorization schema


* NB: The package ccv1p0.zip includes the file /derived_schema/config.xml which defines the namespace and file
      locations for all of the schemas included in the package.




Additional resources


Common Cartridge Test System v1.0.2		http://www.imsglobal.org/cc/testtool/index.cfm 

Valid Cartridge Test Data Set v1.22 (*)		http://developers.imsglobal.org/alliance/testharness.cfm


* NB: Restricted to members of the CC Alliance


Contents of ccV1p0.zip

The full set of files that define the Common Cartridge Application Profile are available as ccV1p0.zip.
 
The following files are located in the root directory of the zip-file:

�	imscp_v1p2.xsd � the original xsd for Content Packaging v1.2

�	imscc_c1p2maeV0p15.xml - defines the modifications made to the CPv1.2 xsd in creating the CC profile. 

�	index.xml

�	license.html

There are also a number of subdirectories off the root, each containing a zip file of an auxiliary profile as follows:

/profile_0/imscc_a.zip			Authorization profile 

/profile_1/imscc_e.zip			Content Packaging extensions profile

/profile_2/imscc_m.zip			Cartridge metadata IEEE LOM (loose binding) profile

/profile_3/imscc_mR.zip			Roles metadata IEEE LOM (loose binding) profile

/profile_4/imscc_q.zip			Question & Test Interoperability profile

/profile_5/imscc_w.zip			IMS weblinks

/profile_6/imscc_d.zip			Discussion topics profile

These profiles are provided for inspection with the IMS SchemaProf tool.

Finally, the /derived_schema subdirectory contains the profiled XML schemas and Schematron rules. Only the files within this directory are used by the IMS Common Cartridge Test System. The derived schemas have names of the form 
�_localised.xsd 

while the files containing the derived Schematron rules have names ending in 

�_constraintsDocument.scmt.

The derived data for the IMS Content Packaging Profile is located immediately in the directory derived_schema. The data for the auxiliary profiles are in the subdirectories named domainProfile_0,�, domainProfile_6. 

The file derived_schema/config.xml maps the namespaces specified in the Common Cartridge profile to the locations of the derived data (i.e., below the /derived_schema directory) defining the respective namespace.


